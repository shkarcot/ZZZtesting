#Environment dependencies

    node    : v6.9.1 or above
    npm     : v3.10.8 or above
    gulp    : CLI version 3.9.1

# add Dependencies

    npm install
    npm rebuild node-sass

# to run development app

    gulp run

# to build

    gulp package
