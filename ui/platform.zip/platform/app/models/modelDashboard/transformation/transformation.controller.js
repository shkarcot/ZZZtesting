module.exports = ['$scope','entitydata','$rootScope','ngDialog','Upload','$state','$window','$location','$timeout','$http','$uibModalInstance','transformationService', function($scope,entitydata,$rootScope,ngDialog,Upload,$state,$window,$location,$timeout,$http,$uibModalInstance,transformationService) {
	'use strict';

    	var vm = this;
		vm.clear = clear;
		vm.piplineObj = entitydata;
		//$scope.jsonElements = [];

  var chartDataModel = [{	nodes: [],connections: []	}];
                    $scope.chartViewModel = new flowchart.ChartViewModel(chartDataModel[0]);

        $scope.jsonElements = [
                          {
                            "feature_extractors": [
                              {
                                "createdBy": "01-01-2018 01:01:01",
                                "description": "Term frequency-inverse document frequency (TF-IDF) is a feature vectorization method widely used in text mining to reflect the importance of a term to a document in the corpus. Denote a term by t, a document by d, and the corpus by D. Term frequency TF(t,d) is the number of times that term t appears in document d, while document frequency DF(t,D) is the number of documents that contains term t.",
                                "id": 2016,
                                "info": '{"displayNm":"TF-IDF","classId" :"TFIDF","description": "sdasdasdasdasdasdasdas","nodes": [{"name": "TFIDF","id": 23,"x": 0,"y": 0,"width":50,"height":20,"inputConnectors": [{"name": "A"}],"outputConnectors": [{"name": "1"}],"property":[{"type": "text", "name": "firstName", "label": "FirstName" ,"data":""},{"type": "text", "name": "lastName", "label": "LastName" ,"data":""}]}],"connections":[]}',
                                "name": "TF-IDF",
                                "classId":'TFIDF',
                                "stageGrpNm": "feature_extractors",
                                "statusCdcreatedAt": "ACTIVE",
                                "updatedAt": "111111",
                                "updatedBy": "01-01-2018 01:01:01"
                              },
                              {
                                "createdBy": "01-01-2018 01:01:01",
                                "description": "Word2Vec is an Estimator which takes sequences of words representing documents and trains a Word2VecModel. The model maps each word to a unique fixed-size vector. The Word2VecModel transforms each document into a vector using the average of all words in the document; this vector can then be used as features for prediction, document similarity calculations, etc. Please refer to the MLlib user guide on Word2Vec for more details.",
                                "id": 2017,
                                "info": '{"displayNm": "Word2Vec","classId" :"WORD2VEC","description": "sdasdasdasdasdasdasdas","nodes": [{"name": "WORD2VEC","id": 23,"x": 0,"y": 0,"width":50,"height":20,"inputConnectors": [{"name": "A"}],"outputConnectors": [{"name": "1"}],"property":[{"type": "text", "name": "firstName", "label": "First Name" ,"data":""},{"type": "text", "name": "lastName", "label": "Last Name" ,"data":""}]}],"connections":[]}',
                                "name": "Word2Vec",
                                "classId":'WORD2VEC',
                                "stageGrpNm": "feature_extractors",
                                "statusCdcreatedAt": "ACTIVE",
                                "updatedAt": "111111",
                                "updatedBy": "01-01-2018 01:01:01"
                              }
                            ]
                          },
                          {
                            "feature_transformers": [
                              {
                                "createdBy": "01-01-2018 01:01:01",
                                "description": "Tokenization is the process of taking text (such as a sentence) and breaking it into individual terms (usually words). A simple Tokenizer class provides this functionality. The example below shows how to split sentences into sequences of words.",
                                "id": 2018,
                                "info": '{"displayNm": "Tokenizer","classId" :"TOKENIZER","description": "sdasdasdasdasdasdasdas","nodes": [{"name": "TOKENIZER","id": 23,"x": 0,"y": 0,"width":50,"height":20,"inputConnectors": [{"name": "A"}],"outputConnectors": [{"name": "1"}],"property":[{"type": "text", "name": "firstName", "label": "First Name" ,"data":""},{"type": "text", "name": "lastName", "label": "Last Name" ,"data":""}]}],"connections":[]}',
                                "name": "Tokenizer",
                                "classId":'TOKENIZER',
                                "stageGrpNm": "feature_transformers",
                                "statusCdcreatedAt": "ACTIVE",
                                "updatedAt": "111111",
                                "updatedBy": "01-01-2018 01:01:01"
                              }
                            ]
                          }
                        ];

 // console.log(data);
		function clear()
		{
			$uibModalInstance.dismiss('cancel');
		}

	// Add node to click handle .
     $scope.handleNodeClicked =  function()
	 {
         $scope.jsonElementsupdate = [];
		  var selectedNodes = $scope.chartViewModel.getSelectedNodes();
          $scope.formFields =  selectedNodes[0].data.property;

	 }


	$scope.deleteSelected = function ()
	{

		$scope.chartViewModel.deleteSelected();
		//$scope.saveNodeDataModel
	};

	$scope.gererate = function()
	{
	    console.time('start guid');
        var d = new Date().getTime();
        var uuid = 'xxx-xxx'.replace(/[xy]/g, function(c) {
          var r = (d + Math.random() * 16) % 16 | 0;
          d = Math.floor(d / 16);
          return (c == 'x' ? r : (r & 0x3 | 0x8)).toString(16);
        });
        console.timeEnd('start guid');
        return uuid;
	}

	//
	// Create the view-model for the chart and attach to the scope.

	//
	//$scope.chartViewModel = new flowchart.ChartViewModel(chartDataModel);
	//$scope.newNodeDataModel = '';
	$scope.saveNodeDataModel = [];
	$scope.createNodeJson = [];
	 $scope.flowchartdraw = function(dataValue)
    {
      $scope.datav = dataValue;
      $scope.rngESUS = $scope.gererate();
      var keys= [];
       angular.forEach($scope.jsonElements, function(value, key) {

             angular.forEach(value, function(value1, key1) {
             for(var i=0;i<value1.length;i++)
             {
               if(value1[i].classId == $scope.datav)
               {
                  // $scope.data  = $scope.jsonElements[i].portattrib.id
                  console.log(value1[i].info);

                     $scope.datainfo = JSON.parse(value1[i].info);
                  $scope.datainfo.nodes[0].name = $scope.datainfo.nodes[0].name+' '+ $scope.rngESUS;
                  $scope.datainfo.nodes[0].id = $scope.rngESUS;
                  $scope.datainfo.nodes[0].x = $scope.datainfo.nodes[0].x+45;
                   $scope.datainfo.nodes[0].y = $scope.datainfo.nodes[0].y+45;
               $scope.data  = angular.copy($scope.datainfo.nodes[0]);
             // $scope.chartViewModel.push({'property':$scope.datainfo.nodes[0].property});
               $scope.chartViewModel.addNode($scope.data);
               $scope.saveNodeDataModel.push({'nodes': $scope.data,'property':$scope.datainfo.nodes[0].property});


            // $scope.jsonElements[i].nodes[0].name = $scope.jsonElements[i].nodes[0].name+' '+ $scope.rngESUS;
            // $scope.jsonElements[i].nodes[0].id = $scope.rngESUS;
            // $scope.jsonElements[i].nodes[0].x = $scope.jsonElements[i].nodes[0].x+45;
             //$scope.jsonElements[i].nodes[0].y = $scope.jsonElements[i].nodes[0].y+45;
           //  $scope.data  = angular.copy($scope.jsonElements[i].nodes[0]);
              //$scope.chartViewModel.push({'property':$scope.jsonElements[i].property});
            // $scope.chartViewModel.addNode($scope.data);
             //$scope.saveNodeDataModel.push({'nodes': $scope.data,'property':$scope.jsonElements[i].property});

               }

             }


        });
        });





    }

    $scope.jsonGenerater = function()
    {
        $scope.savenodeJsonModel = [];
       $scope.arraynodes = [];
       $scope.arrayproprty = [];
       $scope.arrayconnn = [];
                for(var i=0;i<$scope.chartViewModel.data.nodes.length;i++)
              {
                      for(var j=0;j<$scope.saveNodeDataModel.length;j++)
                  {
                     if($scope.chartViewModel.data.nodes[i].name == $scope.saveNodeDataModel[j].nodes.name)
                     {
                       $scope.arraynodes.push($scope.chartViewModel.data.nodes[i]);
                     }
                  }

              }
                for(var k=0;k<$scope.chartViewModel.data.connections.length;k++)
              {
                $scope.arrayconnn.push($scope.chartViewModel.data.connections[k]);
              }
             $scope.savenodeJsonModel.push({'nodes':$scope.arraynodes,'connections': $scope.arrayconnn});
             return  $scope.savenodeJsonModel;

    }
    $scope.saveDrawNode =  function()
    {
       //console.log("hhh");
      var jsongenerate =  $scope.jsonGenerater();
      //console.log("json::generateing::"+JSON.stringify(jsongenerate));
      //vm.piplineObj.id =  '';
      vm.piplineObj.stageInfo = JSON.stringify(jsongenerate);
      $http.post('http://localhost:18098/pipe',vm.piplineObj, {
				headers : {
					'Content-Type' : 'application/json'
				}

			}).success(function(data) {

            console.log("pipline: ::"+JSON.stringify(data));
             // $scope.




			}).error(function() {
				//AlertService.error('Server Error:Please contact to admin');

			});

    }
    $scope.SaveData = function()
    {
      console.log("save::data:11"+JSON.stringify($scope.formFields));
    }

    $scope.piplineDetails = function()
    {
         // console.log("eventdd::"+$scope.piplineId.id);
			$http.get('http://localhost:18098/pipes/'+vm.piplineObj.id, {
				headers : {
					'Content-Type' : 'application/json'
				}

			}).success(function(data) {

           // console.log("pipline: ::"+JSON.stringify(data));

             vm.piplineObj = data;
             console.log("pipline: ::"+JSON.stringify(vm.piplineObj));
             var jsonstrin = JSON.parse(data.stageInfo);
             if(Object.keys(jsonstrin).length != '0')
              {
                   var chartdata = jsonstrin[0].nodes;
                  for(var i=0;i<chartdata.length;i++)
                  {
                    $scope.saveNodeDataModel.push({'nodes':chartdata[i],'property':chartdata[i].property});
                  }
                   $scope.chartViewModel = new flowchart.ChartViewModel(jsonstrin[0]);
              }
              else
              {
                    var chartDataModel = [{	nodes: [],connections: []	}];
                    $scope.chartViewModel = new flowchart.ChartViewModel(chartDataModel[0]);

              }

			}).error(function() {
				//AlertService.error('Server Error:Please contact to admin');

			});

    }
    $scope.piplineDetails();
   /*  $scope.piplineStages = function()
    {
       $scope.jsonElements = [];
         // console.log("eventdd::"+$scope.piplineId.id);
			$http.get('http://localhost:18098/stages', {
				headers : {
					'Content-Type' : 'application/json'
				}

			}).success(function(data) {

             for(var i=0; i<data.length;i++)
             {
                $scope.jsonElements.push(data[i]);
             }


			}).error(function() {
				//AlertService.error('Server Error:Please contact to admin');

			});

    }
    $scope.piplineStages();*/





}];