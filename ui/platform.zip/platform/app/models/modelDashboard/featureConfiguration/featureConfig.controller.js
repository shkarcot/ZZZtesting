module.exports = ['$scope','entity','$rootScope','ngDialog','Upload','$state','$window','$location','$timeout','$http','$uibModalInstance', function($scope,entity,$rootScope,ngDialog,Upload,$state,$window,$location,$timeout,$http,$uibModalInstance) {
	'use strict';

    	var vm = this;
		vm.clear = clear;
		vm.feature = entity;
		vm.save = save;
		vm.getstageDeatilsByID =getstageDeatilsByID;
		vm.feedback = {};
		$scope.loaderfeedback = false;
		$scope.mySwitch = "false";

        console.log("vm.feature::id::"+JSON.stringify(vm.feature.view));
       if(vm.feature.view == "1")
       {
       $scope.mySwitch = "true";
       }
       else{
           $scope.mySwitch = "false";
       }

		// cancel button then close to form dialog popup.
		function clear()
		{
			$uibModalInstance.dismiss('cancel');
		}

		// click on save button then all data send to server.data is updated.
		function save()
		{

			$http.post('http://localhost:18098/stage',vm.feature, {
				headers : {
					'Content-Type' : 'application/json'
				}

			}).success(function(data) {

           // console.log("pipline: ::"+JSON.stringify(data));


			}).error(function() {
				//AlertService.error('Server Error:Please contact to admin');

			});

		}
	   // success callback.
		function onSaveSuccess(result)
		{
			//$scope.$emit('pcswebApp:jobProcessUpdate', result);
			$uibModalInstance.close(result);
			//vm.isSaving = false;
		}

		// error callback.
		function onSaveError()
		{
			vm.isSaving = false;
		}
		function getstageDeatilsByID()
		{
		   $http.get('http://localhost:18098/stages/'+vm.feature.id , {
				headers : {
					'Content-Type' : 'application/json'
				}

			}).success(function(data) {
                   // console.log(""+JSON.stringify(data));
				  vm.feature = data;

			}).error(function() {
				$scope.showgraph = false;

			});

		}
		getstageDeatilsByID();



}];