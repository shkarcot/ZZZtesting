(function() {
	'use strict';



	module.exports = angular.module('console.featureconfig', [	])
        .controller('FeatureConfigController', require('./featureConfig.controller.js'))
         .config(['$stateProvider', function($stateProvider) {
            $stateProvider.state('featureconfig', {
               parent: 'app.modelDashboard',
               url: '/featureconfig/{id}/{view}',
               onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    template: require('./featureConfig.html'),
                    controller: 'FeatureConfigController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity:{id : $stateParams.id,
                                 view :$stateParams.view,
                                 classId:null,
                                 reason:null,
                                 description : null,
                                 stageGrpNm: null,
                                 statusCd:null,
                                 stageInfo:"{}",
                                 stageNm:null,
                                 statusCdcreatedAt:null,
                                 createdBy:null,
                                 updatedAt:null,
                                 updatedBy:null
                                 }
                    }

                }).result.then(function() {
                    //$state.go('job-process', null, { reload: 'job-process' });
                }, function() {
                    $state.go('^');
                });
            }],

				data: {
					menuConfig: {
						'title': 'Product',
						'iconCls': 'cube'
					}

				}
            });
        }]);
})();