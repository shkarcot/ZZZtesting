(function() {
	'use strict';



	module.exports = angular.module('console.xstageconfig', [	])
        .controller('xStageConfigController', require('./xstageconfig.controller.js'))
         .config(['$stateProvider', function($stateProvider) {
            $stateProvider.state('xstageconfig', {
               parent: 'app.modelDashboard',
               url: '/xstageconfig/{id}',
               onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    template: require('./xstageconfig.html'),
                    controller: 'xStageConfigController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity:{     id : $stateParams.id,
                                    createdAt : null,
                                    createdBy: null,
                                    description: null,
                                    endAt: null,
                                    errorCd: null,
                                    errorDesc: null,
                                    pipeInfo: "{}",
                                    pipejobNm: null,
                                    reason: null,
                                    startAt: null,
                                    statusCd: null,
                                    submitAt: null,
                                    updatedAt: null,
                                    updatedBy: null
                                }
                    }

                }).result.then(function() {
                    //$state.go('job-process', null, { reload: 'job-process' });
                }, function() {
                    $state.go('^');
                });
            }],

				data: {
					menuConfig: {
						'title': 'Product',
						'iconCls': 'cube'
					}

				}
            });

        }]);
})();