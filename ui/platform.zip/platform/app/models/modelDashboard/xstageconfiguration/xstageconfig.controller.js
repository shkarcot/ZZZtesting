module.exports = ['$scope','entity','$rootScope','ngDialog','Upload','$state','$window','$location','$timeout','$http','$uibModalInstance', function($scope,entity,$rootScope,ngDialog,Upload,$state,$window,$location,$timeout,$http,$uibModalInstance) {
	'use strict';

    	var vm = this;
		vm.clear = clear;
		vm.xstageconfig = entity;
		vm.save = save;
		vm.feedback = {};
		$scope.loaderfeedback = false;
		$scope.mySwitch = "false";



		// cancel button then close to form dialog popup.
		function clear()
		{
			$uibModalInstance.dismiss('cancel');
		}

		// click on save button then all data send to server.data is updated.
		function save()
		{
           vm.xstageconfig.createdAt = "01-26-2019 12:01:28";
            vm.xstageconfig.createdBy = "99999";
             vm.xstageconfig.updatedAt =  "01-26-2019 12:01:28";
               vm.xstageconfig.updatedBy = "888888";

		  $http.post('http://localhost:18098/pipejob',vm.xstageconfig, {
				headers : {
					'Content-Type' : 'application/json'
				}

			}).success(function(data) {
             $uibModalInstance.dismiss('cancel');
			  vm.xstageconfig = data;

			}).error(function() {


			});

		}
	   // success callback.



        function piplineJobByID()
        {
           $http.get('http://localhost:18098/pipejobs/'+vm.xstageconfig.id, {
				headers : {
					'Content-Type' : 'application/json'
				}

			}).success(function(data) {

			  vm.xstageconfig = data;
			  vm.xstageconfig.pipeInfo = JSON.parse(data.pipeInfo);

			}).error(function() {


			});
        }
        piplineJobByID();



}];