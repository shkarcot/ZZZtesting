(function() {
	'use strict';

	module.exports = [function() {
		var vm = this;
		vm.name = '';
	}]
})();