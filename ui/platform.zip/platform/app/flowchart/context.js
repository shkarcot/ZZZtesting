(function(angular) {
  var ngContextMenu = angular.module('directive.contextMenu', []);


})(window.angular);