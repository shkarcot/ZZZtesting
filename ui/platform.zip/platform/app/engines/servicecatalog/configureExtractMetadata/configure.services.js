'use strict';
angular.module('console.configureMetadataServices', [])
.factory('configureMetadataServices', function($q, $http,httpPayload) {

    var configureMetadataServices = {

    };

    return configureMetadataServices;
});
