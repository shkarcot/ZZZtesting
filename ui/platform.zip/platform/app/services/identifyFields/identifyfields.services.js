(function() {
'use strict';
angular.module('console.identifyFieldsServices', [])
.factory('identifyFieldsServices', function($q, $http,httpPayload) {




    var services = {

    };

    return services;
});
})();